<?php
    require 'database.php';

    if(isset($_POST['pid'])) {
        $pid = $_POST['pid'];
        $pname = $_POST['pname'];
        $pprice = $_POST['pprice'];
        $pimage = $_POST['pimage'];
        $pqty = 1;
        
        $stmt = $connect->prepare("SELECT productoID from carrito WHERE productoID=?");
        $stmt->bind_param("i",$pid);
        $stmt->execute();
        $res = $stmt->get_result();
        $r = $res->fetch_assoc();
        $code = $r['productoID'] ?? '';

        if(!$code) {
            $query = $connect->prepare("INSERT INTO carrito (nombreProducto, precioProducto, imagenProducto, cantidad, precioTotal, productoID) VALUES(?,?,?,?,?,?)");
            $query->bind_param("ssssss", $pname, $pprice, $pimage, $pqty, $pprice, $pid);
            $query->execute();

            echo '<div class="alert alert-success alert-dismissible mt-2">
						  <button type="button" class="close" data-dismiss="alert">&times;</button>
						  <strong>Item added to your cart!</strong>
				</div>';
        } else {
            echo '<div class="alert alert-danger alert-dismissible mt-2">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Item already added to your cart!</strong>
          </div>';
        }
    }
?>