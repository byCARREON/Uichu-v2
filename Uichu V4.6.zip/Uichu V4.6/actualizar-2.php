<?php 
//Database Connection
include('database.php');

    if(isset($POST['update_btn'])) {
        $edit_id = $_POST['edit_id'];
        $edit_nombre = $_POST['edit_nombre'];
        $edit_descripcion = $_POST['edit_descripcion'];
        $edit_precio = $_POST['edit_precio'];
        $edit_categoria = $_POST['edit_categoria'];
        $edit_imagen = $_FILES["img"]["name"];

        // get the image extension
        $extension = substr($img,strlen($img)-4,strlen($img));
        // allowed extensions
        $allowed_extensions = array(".jpg","jpeg",".png");
        // Validation for allowed extensions .in_array() function searches an array for a specific value.
        if(!in_array($extension,$allowed_extensions))
        {
        echo "<script>alert('Invalid format. Only jpg / jpeg/ png format allowed');</script>";
        }
        else
        {

        $query = "UPDATE producto SET nombre='$edit_nombre', descripcion='edit_descripcion', precio='$edit_precio', categoria='$edit_categoria', imagen='edit_imagen' WHERE productoID='$edit_id' ";

        $query_run = mysqli_query($connect, $query);

        if($query_run) {
            move_uploaded_file($_FILES["img"]["tmp_name"],"img/products/".$imgnewfile);
            $_SESSION["success"] = 'producto agregado';
            header("location: dashboard.php");
        } else {
            $_SESSION["status"] = 'producto no actualizado';
            header("location: dashboard.php");
        }}
    }
?>

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Üichu - Ingresar</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.html"><h1>Üichu</h1></a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.html">Nosotros</a></li>
                        <li class="nav-item"><a class="nav-link" href="shop.php">Tienda</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact-us.html">Contacto</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="usuario"><a href="login.php"><i class="fa-solid fa-user"></i></a></li>
                        <li class="side-menu">
							<a href="cart.html">
								<i class="fa fa-shopping-bag"></i>
								<span class="badge">3</span>
								<p>Mi Carrito</p>
							</a>
						</li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
                <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                        <li>
                            <a href="#" class="photo"><img src="img/products/product-1.jpg" class="cart-thumb" alt="" /></a>
                            <h6><a href="#">Delica omtantur </a></h6>
                            <p>1x - <span class="price">$80.00</span></p>
                        </li>
                        <li>
                            <a href="#" class="photo"><img src="images/img-pro-02.jpg" class="cart-thumb" alt="" /></a>
                            <h6><a href="#">Omnes ocurreret</a></h6>
                            <p>1x - <span class="price">$60.00</span></p>
                        </li>
                        <li>
                            <a href="#" class="photo"><img src="images/img-pro-03.jpg" class="cart-thumb" alt="" /></a>
                            <h6><a href="#">Agam facilisis</a></h6>
                            <p>1x - <span class="price">$40.00</span></p>
                        </li>
                        <li class="total">
                            <a href="#" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                            <span class="float-right"><strong>Total</strong>: $180.00</span>
                        </li>
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->
    
    <div class="login-container">
        <div class="form-group-login">    
            <a href="dashboard.php"><button type="button" class="btn hvr-hover" id="button-db"><i class="fa-solid fa-backward"></i> Regresar</button></a>
        </div>

        <?php
        if(isset($_POST['edit_data_btn'])) {
            $id = $_POST['edit_id'];
            $query = "SELECT * FROM producto where productoID = '$id'";
            $query_run = mysqli_query($connect, $query);

            foreach($query_run as $row) {
        ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">

            <input type="hidden" name="edit_id" value="<?php echo $row['productoID'];?>">
            <h1>Actualizar Producto</h1>
            <div class="form-group-login">

                <label for="imagen">Imagen</label><br>
                <input type="file" name="img" value="<?php echo $row['imagen'];?>" class="form-control">
            </div>
            <div class="form-group-login">
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" class="form-control" value="<?php echo $row['nombre'];?>" maxlength="30" placeholder="ej. Carne Cocida" required>
            </div>
            <div class="form-group-login">
                <label for="descripcion">Descripción</label>
                <textarea rows="3" name="descripcion" class="form-control" <?php echo $row['descripcion'];?> maxlength="250" placeholder="ej. Carne cocida con un sabor ahumado y apetitoso para tu mascota" required><?php echo $row['descripcion'];?></textarea>
            </div>
            <div class="form-group-login">
                <label for="precio">Precio</label>
                <input type="number" name="precio" class="form-control" value="<?php echo $row['precio'];?>" min="0"  placeholder="ej. 190" required>
            </div>
            <div class="form-group-login">
                <label for="categoria">Categoría</label>
                <input type="text" name="categoria" class="form-control" value="<?php echo $row['categoria'];?>" maxlength="30" placeholder="ej. Premio" required>
            </div>
            <input type="hidden" name="productoID" value="<?php echo $productoID; ?>"/>

            <input id="button-submit" name="update_btn" type="submit" class="btn hvr-hover" value="Actualizar Producto">
            </form>

        <?php
            }
        }
        ?>
        
    </div>

    <!-- Start Footer  -->
    <footer>
        <div class="footer-main">
            <div class="container">
				<div class="row">

					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Social Media</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
							<ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<hr>
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>Sobre Üichu</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p> 
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p> 							
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <h4>Información</h4>
                            <ul>
                                <li><a href="#">Sobre nosotros</a></li>
                                <li><a href="#">Servicio al cliente</a></li>
                                <li><a href="#">Términos &amp; Condiciones</a></li>
                                <li><a href="#">Políticas de Privacidad</a></li>
                                <li><a href="#">Información de entrega</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contáctanos</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Dirección: Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>Monterrey, N.L.</p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Teléfono: <a href="tel:+1-888705770">+1-888 705 770</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">uichu@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer  -->

    <!-- Start copyright  -->
    <div class="footer-copyright">
        <p class="footer-company">Todos los derechos reservados. &copy; 2022 <a href="#">Üichu</a></p>
    </div>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
